#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(RColorBrewer)
library(tidyverse)
library(stringr)
library(mapview)
library(leaflet)
library(sf)


residualsRichmond <- read_csv("20200730_mapRichmond.csv")
Richmond_housing_geo<-readRDS("Richmond_housing_geo")
VAcounties<-readRDS("VAcounties")


Richmond_housing_geo$GEOID <- as.double(Richmond_housing_geo$GEOID)
Richmond_geom <- Richmond_housing_geo %>% select(GEOID, geometry)
residual_R <- residualsRichmond %>% left_join(unique(Richmond_geom), by = "GEOID") %>% st_as_sf()

mybins <- c(-5,0,5,10,15)
# Define UI for application that draws a histogram
ui <- fillPage(

    # Application title
    titlePanel("Eviction Intensity Indicator"),

    # Sidebar with a slider input for number of bins 

        # Show a plot of the generated distribution
    mainPanel(
        leafletOutput("map", height = 600), width = 12
    )
    
)

# Define server logic required to draw a histogram
server <- function(input, output) {

    output$map <- renderLeaflet({
        mypalette <- colorBin(palette="viridis", domain=residual_R$ncehat, na.color="transparent", bins=mybins)
        
        leaflet(data = residual_R) %>%
            addTiles() %>%
            addPolygons(
                fillColor = ~mypalette(residual_R$`ncehat2`),
                stroke=TRUE,
                weight = 1,
                smoothFactor = 0.5,
                opacity = 1.0,
                fillOpacity = 0.5,
                label=paste("Tract: ",residual_R$GEOID, ", Value: ",residual_R$ncehat2),
                highlightOptions = highlightOptions(color = "white",
                                                    weight = 2,
                                                    bringToFront = TRUE)) %>%
            addLegend(pal=mypalette, position = "topright", values = ~residual_R$ncehat2,
                      opacity = 0.5, title = "Eviction Intensity Indicator") %>%
            addPolylines(data = VAcounties, color = "black", opacity = 0.5, weight = 1)
    })
}

# Run the application 
shinyApp(ui = ui, server = server)
