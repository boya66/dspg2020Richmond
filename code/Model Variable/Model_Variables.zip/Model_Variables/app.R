#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(tidycensus)
library(tidyverse)
library(stringr)
library(mapview)
library(leaflet)
library(sf)
years = c("2013","2014", "2015", "2016", "2017", "2018")


acs_all_year <- readRDS("acs_2018_2013.rds")

# Define UI for application that draws a histogram
ui <- fluidPage(

    # Application title
    titlePanel("Visualization of the Socio-Demographic Factors Over Time"),

    # Sidebar with a slider input for number of bins 
    sidebarLayout(
        sidebarPanel(
            tags$style(type = "text/css", ".irs-grid-pol.small {height: 0px;}"),
            sliderInput("year",
                        "Choose year",
                        min = 2013,
                        max = 2018,step = 1,
                        value = 2018, animate = T, sep= ""),
            selectInput("Demographic_Variable", "Select a Demographic Variable",
                        c("Poverty Rate" = 'poverty_rate',
                          "Median Household Income" = 'median_household_income',
                          "Percentage White Population" = 'pct_white',
                          "Percentage African American" = 'pct_af_am',
                          "Percentage Hispanic" = 'pct_hispanic',
                          "Percent Asian" = 'pct_asian',
                          "Percent Other Race" = 'pct_other_race',
                          "Unemployment Percentage" = 'perc_16yrs_and_over_unemployed',
                          "Percentage with High School Diploma" = 'percw_HS_diploma',
                          "Percentage below High School Diploma" = 'per_below_HS_diploma',
                          "Percentage with Bachelor Degree or more" = 'per_bach_and_up'
                          ))
        ),

        # Show a plot of the generated distribution
        mainPanel(
            leafletOutput("map")
        )
    )
)

# Define server logic required to draw a histogram
server <- function(input, output) {
    
    
    
    
    output$map <- renderLeaflet(
        {
            max_number = max(acs_all_year[,input$Demographic_Variable], na.rm = TRUE)
            min_number = min(acs_all_year[,input$Demographic_Variable], na.rm = TRUE)
            acs <- acs_all_year %>% filter(year == input$year)
            
            #mypalette <- colorNumeric(palette="viridis", acs[,input$Demographic_Variable])
            mypalette <- colorNumeric(palette="viridis", c(min_number,max_number))
            leaflet(acs %>% st_as_sf()) %>%
                addTiles() %>%
                addPolygons(color = ~mypalette(acs[, input$Demographic_Variable]),
                            smoothFactor = 0.2, fillOpacity=0.6, weight = 1,stroke = F, label=paste("Tract: ",acs$NAME.x, ", Value: ",acs[, input$Demographic_Variable]))%>%
                setView(lng = -077.5129368 , lat = +37.5186235, zoom = 11) %>%
                
                addLegend(pal=mypalette,position = "topright",values = c(min_number,max_number), title = "Percentage")
                
            
        }
    )
}

# Run the application 
shinyApp(ui = ui, server = server)
