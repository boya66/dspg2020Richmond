#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(tigris)
library(sf)
library(dplyr)
library(tidyverse)
library(leaflet)
library(DT)
library(magrittr)
library(mapview)
library(readr)

zip_codes <- c(23234, 23231, 23224,23223, 23219, 23225, 23226, 23222, 23220, 23227, 23230, 23221, 23173, 23235)

richmond_zipcode_level_2020 <- read_csv("richmond_zipcode_level_2020.csv",
                                        col_types = cols(week_date = col_date(format = "%Y-%m-%d")))

VAcounties<-readRDS("VAcounties")

richmond_zipcode_level_2020 <- richmond_zipcode_level_2020 %>% mutate("month" = as.numeric(format(week_date , "%m")))  %>% filter(GEOID %in% zip_codes)
zip_code_geo_2010 <- st_read("tl_2010_51_zcta510.shp")
zip_code_geo_2010 <- zip_code_geo_2010 %>% rename(Zip_Code = ZCTA5CE10 )

max_rich_mond_eviction_filing <- richmond_zipcode_level_2020 %>% group_by(GEOID, month) %>% summarize(filings_2020 = sum(filings_2020),
                                                                                                    filings_avg = sum(filings_avg, na.rm = T))


#max_eviction_filing <-c(0, max(max_rich_mond_eviction_filing$filings_2020))
max_eviction_filing <-c(0, 350)
# Define UI for application that draws a histogram
ui <- fluidPage(

  # Application title
  titlePanel("2020 Eviction Fillings by Zip Code"),

  # Sidebar with a slider input for number of bins
  sidebarLayout(
    sidebarPanel(
      selectInput("month", "Month:",
                  c("January" = 1,
                    "February" = 2,
                    "March" = 3, "April" =4, "May"=5))
    ),

    # Show a plot of the generated distribution
    mainPanel(
      leafletOutput("evction_rate")
    )
  )
)

# Define server logic required to draw a histogram
server <- function(input, output) {

  output$evction_rate <- renderLeaflet({


    june_data <- richmond_zipcode_level_2020 %>% filter(month == input$month)
    june_data_group_zip <- june_data %>% group_by(GEOID) %>% summarize(filings_2020 = sum(filings_2020),
                                                                       filings_avg = sum(filings_avg, na.rm = T))

    june_data_group_zip <- june_data_group_zip %>% rename(Zip_Code = GEOID  )
    eviction_with_geometry <- june_data_group_zip %>% left_join(zip_code_geo_2010, by = "Zip_Code")  %>%
      drop_na()%>% st_as_sf()


    mypalette <- colorQuantile(palette="viridis", max_eviction_filing,n=10)

    #mypalette <- colorQuantile(palette="viridis", c(0,max_eviction),n=12)

    #construct map
    leaflet() %>%
      addTiles() %>%
      addPolygons(data=eviction_with_geometry,color = ~mypalette(eviction_with_geometry$filings_2020),
                  smoothFactor = 0.2, fillOpacity=0.6, weight = 1,stroke = F, label=paste(" Evicion filing For zip code ", eviction_with_geometry$Zip_Code, ", Value: ",eviction_with_geometry$filings_2020))%>%
      addLegend(pal=mypalette,position = "topright",values = max_eviction_filing,
                labFormat = function(type, cuts, p) {
                  n = length(cuts)
                  paste0(cuts[-n], " &ndash; ", cuts[-1])},opacity = .6) %>%
      setView(lng = -077.5129368 , lat = +37.5186235, zoom = 10) %>%
      addPolylines(data = VAcounties, color = "black", opacity = 1, weight = 1)

    #m1 <- mapview(eviction_with_geometry, zcol = "filings_2020",layer.name = paste(" For month ", input$month))

    #m1@map <- m1@map  %>% addPolylines(data = VAcounties, color = "red", opacity = 1, weight = 1)
    #m1@map


  })

}

# Run the application
shinyApp(ui = ui, server = server)

